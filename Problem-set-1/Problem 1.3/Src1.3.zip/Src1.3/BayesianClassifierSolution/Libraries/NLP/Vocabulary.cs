﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NLP
{
    public class Vocabulary
    {
        // Write this class - it should contain a data structure
        // that holds all the words in the vocabulary
        // Use a Dictionary<string, Token> for this purpose.

        // NOTE: In Problem1.1, the Vocabulary class is not used, 
        // instead (only for that problem) the vocabulary is represented
        // as a simple List<Token>.
    }
}
